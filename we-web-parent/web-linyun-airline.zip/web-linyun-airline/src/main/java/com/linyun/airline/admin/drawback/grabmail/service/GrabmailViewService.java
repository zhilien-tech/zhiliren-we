package com.linyun.airline.admin.drawback.grabmail.service;

import org.nutz.ioc.loader.annotation.IocBean;
import org.nutz.log.Log;
import org.nutz.log.Logs;

import com.linyun.airline.admin.drawback.grabmail.entity.TGrabMailEntity;
import com.uxuexi.core.web.base.service.BaseService;

@IocBean
public class GrabmailViewService extends BaseService<TGrabMailEntity> {
	private static final Log log = Logs.get();

}