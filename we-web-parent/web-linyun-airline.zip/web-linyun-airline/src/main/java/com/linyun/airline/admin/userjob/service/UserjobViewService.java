package com.linyun.airline.admin.userjob.service;

import com.uxuexi.core.web.base.service.BaseService;
import com.linyun.airline.entities.TUserJobEntity;

import org.nutz.ioc.loader.annotation.IocBean;
import org.nutz.log.Log;
import org.nutz.log.Logs;

@IocBean
public class UserjobViewService extends BaseService<TUserJobEntity> {
	private static final Log log = Logs.get();
   
}