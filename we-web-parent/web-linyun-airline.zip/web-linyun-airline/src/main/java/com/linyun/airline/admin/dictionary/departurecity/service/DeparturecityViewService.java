package com.linyun.airline.admin.dictionary.departurecity.service;

import org.nutz.ioc.loader.annotation.IocBean;

import com.linyun.airline.admin.dictionary.departurecity.entity.TDepartureCityEntity;
import com.uxuexi.core.web.base.service.BaseService;

@IocBean
public class DeparturecityViewService extends BaseService<TDepartureCityEntity> {

}