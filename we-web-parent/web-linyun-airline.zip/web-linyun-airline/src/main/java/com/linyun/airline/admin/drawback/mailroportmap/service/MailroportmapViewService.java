package com.linyun.airline.admin.drawback.mailroportmap.service;

import org.nutz.ioc.loader.annotation.IocBean;

import com.linyun.airline.admin.drawback.mailroportmap.entity.TGrabMailReportMapEntity;
import com.uxuexi.core.web.base.service.BaseService;

@IocBean
public class MailroportmapViewService extends BaseService<TGrabMailReportMapEntity> {

}