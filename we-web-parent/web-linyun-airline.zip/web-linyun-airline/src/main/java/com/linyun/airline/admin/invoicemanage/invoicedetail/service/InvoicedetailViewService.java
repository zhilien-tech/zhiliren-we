package com.linyun.airline.admin.invoicemanage.invoicedetail.service;

import org.nutz.ioc.loader.annotation.IocBean;

import com.linyun.airline.entities.TInvoiceDetailEntity;
import com.uxuexi.core.web.base.service.BaseService;

@IocBean
public class InvoicedetailViewService extends BaseService<TInvoiceDetailEntity> {

}