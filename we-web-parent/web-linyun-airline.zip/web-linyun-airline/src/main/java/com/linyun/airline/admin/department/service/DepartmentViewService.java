package com.linyun.airline.admin.department.service;

import com.uxuexi.core.web.base.service.BaseService;
import com.linyun.airline.entities.TDepartmentEntity;

import org.nutz.ioc.loader.annotation.IocBean;
import org.nutz.log.Log;
import org.nutz.log.Logs;

@IocBean
public class DepartmentViewService extends BaseService<TDepartmentEntity> {
	private static final Log log = Logs.get();
   
}